<template>
  <div>
    <p>{{firstName}}</p>
    <p>{{lastName}}</p>
    <p>{{info}}</p>
    <p>{{count}}</p>
    <TestComponentChild
      :label="checkbox.label"
      :id="checkbox.id"
      v-model="checkbox.checked"
      @addToCount="addToCount"
      @reset="reset"
      @returnValue="returnValue"
      @promise="promise"
    />
  </div>
</template>

<script lang="ts">
import {
  Vue,
  Component,
  Emit,
  Inject,
  Model,
  Prop,
  Provide,
  Watch,
  Mixins,
} from 'vue-property-decorator';

import TestComponentChild from './TestComponentChild.vue';

interface CheckBoxValue {
  label: string;
  id: string;
  checked: boolean;
}

Component.registerHooks([
  'beforeRouteEnter',
  'beforeRouteLeave',
  'beforeRouteUpdate', // for vue-router 2.2+
]);

@Component({
  // props: {
  //   info: String,
  // }
  components: {
    TestComponentChild,
  },
  // methods: {
  //   doIt() {
  //     console.log(this.firstName);
  //   }
  // }
})
export default class TestComponent extends Vue {
  // foo: string = 'i am foo';

  // baz: string = 'i am baz';

  firstName: string = 'jane';

  lastName: string = 'zhou';

  count: number = 0;

  checkbox:CheckBoxValue = {
    label: 'Fancy checkbox',
    id: 'checkbox-id',
    checked: true,
  };

  @Prop({ default: 'inside info' }) info!: string

  @Prop(Number) propA!: number

  @Prop({ default: 'default value' }) propB!: string

  @Prop([String, Boolean]) propC!: string | boolean

  // computed
  get computedFirstName(): string {
    return `computed ${this.firstName}`;
  }

  beforeRouteEnter(to, from, next) {
    console.log('beforeRouteEnter22222222');
    next(); // needs to be called to confirm the navigation
  }

  // @Watch('child')
  // onChildChanged(val: string, oldVal: string) { }

  @Watch('checkbox', { immediate: true, deep: true })
  onPersonChanged1(val: CheckBoxValue, oldVal: CheckBoxValue) {
    console.log(this.checkbox);
    this.doIt();
  }

  doIt() {
    console.log(this.firstName);
  }

  addToCount(n: number) {
    console.log('addToCount');
    console.log(n);
  }

  reset(a: any, b: any, c: any) {
    console.log('reset');
    console.log(a, b, c);
  }

  returnValue() {
    console.log('returnValue');
  }

  promise() {
    console.log('promise');
  }

  @Provide() foo = 'i ame foo'

  @Provide('bar') baz = `${this.firstName} ${this.lastName}`

  mounted() {
    console.log(this.foo, this.baz);
  }

  // @Watch('person')
  // onChildChanged2(val: Person, oldVal: Person) { }

  // mounted() {
  //   console.log(1);
  // }
}
</script>
