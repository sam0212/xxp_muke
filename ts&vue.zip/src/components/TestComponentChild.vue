<template>
  <div>
      <h2>@Model</h2>
      <p><input type="checkbox" :id="id" :checked="checked" @change="changed"/> {{label}}</p>
      <h2>@Emit</h2>
      <p>{{count}}</p>
      <p>
        <Button @click="addToCount(1)">btn1</Button>
        <Button @click="resetCount">btn2</Button>
        <Button @click="returnValue">btn3</Button>
        <Button @click="promise">btn4</Button>
      </p>
      <h2>@Inject</h2>
      <p>{{foo}}</p>
      <p>{{bar}}</p>
  </div>
</template>
<script lang="ts">
import Vue from 'vue';
import {
  Component,
  Emit,
  Inject,
  Model,
  Prop,
  Provide,
  Watch,
  Mixins,
} from 'vue-property-decorator';

@Component({})
export default class TestComponentChild extends Vue {
  count: number = 0;

  @Prop() label!: string

  @Prop() id!: string

  // @Prop() value!: boolean

  @Model('change') checked!: boolean

  // @Model('change', { type: Boolean }) checked!: boolean
  changed(ev: any) {
    // this.$emit('input', ev.target.checked);
    this.$emit('change', ev.target.checked);
  }

  @Emit('addToCount')
  addToCount(n: number) {
    console.log(n);
    console.log('addToCount a');
    this.count += n;
  }

  @Emit('reset')
  resetCount() {
    this.count = 0;
  }

  @Emit('returnValue')
  returnValue() {
    console.log('returnValue a');
    return 10;
  }

  @Emit('promise')
  promise() {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(20);
      }, 0);
    });
  }

  @Inject() foo!: string

  @Inject('bar') bar!: string

  // doBtn1() {
  //   console.log(1);
  //   this.$emit('addToCount');
  // }

  // doBtn2() {
  //   console.log(2);
  // }

  // doBtn3() {
  //   console.log(3);
  // }

  // doBtn4() {
  //   console.log(4);
  // }
}
</script>
