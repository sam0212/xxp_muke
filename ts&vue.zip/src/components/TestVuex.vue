<template>
  <div>
    <h1>i am test vuex</h1>
    <p>{{homeInfo}}</p>
    <p>{{homeInfoPlus}}</p>
    <p>
      <Button @click="updateInfo">触发跟store mutaions</Button>
      <Button @click="updateInfoAsync">异步触发跟store actions</Button>
    </p>
    <h2>module</h2>
    <p>{{infoPlus}}</p>
    <p>
      <Button @click="updateInfoAbout">触发跟about store mutaions</Button>
      <Button @click="updateInfoAsyncAbout">异步触发跟about store actions</Button>
    </p>
  </div>
</template>

<script lang="ts">
import {
  Vue,
  Component,
} from 'vue-property-decorator';

import {
  State,
  Getter,
  Action,
  Mutation,
  namespace,
} from 'vuex-class';

const aboutModule = namespace('about');

@Component
export default class TestVuex extends Vue {
  @State homeInfo
  // @State('homeInfo') stateFoo

  @Getter('homeInfoPlus') homeInfoPlus

  @Mutation('updateInfo') updateInfo

  @Action('updateInfoAsync') updateInfoAsync

  @aboutModule.Getter('infoPlus') infoPlus

  @aboutModule.Mutation('updateInfo') updateInfoAbout

  @aboutModule.Action('updateInfoAsync') updateInfoAsyncAbout
}
</script>
