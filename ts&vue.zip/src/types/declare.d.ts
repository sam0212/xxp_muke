declare function getName(name: string): string
