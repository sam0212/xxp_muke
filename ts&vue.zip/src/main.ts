import Vue from 'vue';
import iView from 'iview';
import App from './App.vue';
import router from './router';
import store from './store/store';

import 'iview/dist/styles/iview.css';

import { getName } from './utils/utils';

// let {getName} = utils;

// console.log(getName);

console.log(getName('a'));

// const plugin1: any = {
//   install(vue: any) {
//     console.log(plugin1.installed);
//     // if (plugin1.installed) {
//     //   return;
//     // }
//     console.log(vue);
//     console.log('abcdefabcdefabcdefabcdefabcdef');
//   },
// };

Vue.use(iView);
// Vue.use(plugin1);
// Vue.use(plugin1);

Vue.config.productionTip = false;

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app');
