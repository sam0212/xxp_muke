import Vue from 'vue';
import Vuex from 'vuex';
import about from './about';

Vue.use(Vuex);

interface stateInter {
  homeInfo: string;
}

const defaultState: stateInter = {
  homeInfo: 'i am home info',
};

export default new Vuex.Store({
  state: defaultState,
  getters: {
    homeInfoPlus(state: any) {
      return `${state.homeInfo} plus`;
    },
  },
  mutations: {
    updateInfo(state: any, info: string) {
      console.log(info);
      if (info === 'home info async updated') {
        state.homeInfo = 'home info async updated';
      } else {
        state.homeInfo = 'home info updated';
      }
    },
  },
  actions: {
    updateInfoAsync(store: any, data: any) {
      store.commit('updateInfo', 'home info async updated');
    },
  },
  modules: {
    about,
  },
});
