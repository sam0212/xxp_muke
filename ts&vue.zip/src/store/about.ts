export default {
  namespaced: true,
  state: {
    info: 'hello',
  },
  getters: {
    infoPlus(state: any) {
      return `${state.info} plus`;
    },
  },
  mutations: {
    updateInfo(state: any, info: string) {
      if (typeof info !== 'string') {
        state.info = 'has updated';
      } else {
        state.info = 'async updated';
      }
    },
  },
  actions: {
    updateInfoAsync(store: any, data: any) {
      store.commit('updateInfo', 'async updated');
    },
  },
};
