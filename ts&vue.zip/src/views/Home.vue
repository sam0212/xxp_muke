<template>
  <div class="home">
    <TestComponent info="i am info" />
    <!-- <img alt="Vue logo" src="../assets/logo.png"> -->
    <!-- <HelloWorld msg="Welcome to Your Vue.js + TypeScript App"/> -->
    <TestVuex />
  </div>
</template>

<script lang="ts">
import { Component, Vue } from 'vue-property-decorator';
import HelloWorld from '@/components/HelloWorld.vue'; // @ is an alias to /src
import TestComponent from '../components/TestComponent.vue';
import TestVuex from '../components/TestVuex.vue';

// import _ from 'lodash';
// _.cloneDeep


@Component({
  components: {
    HelloWorld,
    TestComponent,
    TestVuex,
  },
})
export default class Home extends Vue {
  beforeRouteEnter(to, from, next) {
    console.log('beforeRouteEnter home');
    next(); // needs to be called to confirm the navigation
  }

  beforeRouteLeave(to, from, next) {
    console.log('beforeRouteLeave home');
    next(); // needs to be called to confirm the navigation
  }
}
</script>
