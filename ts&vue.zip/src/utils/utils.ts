export function getName(name: string): string {
  return name;
}

export function getName1(name: string): string {
  return name;
}

// export default {
// };
